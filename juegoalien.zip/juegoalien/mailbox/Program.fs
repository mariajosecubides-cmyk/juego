﻿
//
// Comunicacion entre threads
//
// May 19 2026
//

open System

type Mensaje =
| RelojUnoHizoTick
| RelojDosHizoTick
| Redibujar
| TeclaPresionada of ConsoleKey
| Animar

type Misil = {
    X: int
    Y: int
}
type State = {
    Clock1: int
    Clock2: int
    AlienX: int
    AlienY: int
    Misiles: Misil list
}

let initialState = {
    Clock1 = 0
    Clock2 = 0
    AlienX = Console.BufferWidth/2
    AlienY = Console.BufferHeight/2
    Misiles = []
}

let mostrarMensaje x y color (msg:string) =
    Console.SetCursorPosition(x,y)
    Console.ForegroundColor <- color
    msg |> Console.Write

let mostrarMensajeDerecha y color (msg:string) =
    let x = Console.BufferWidth-msg.Length
    mostrarMensaje x y color msg

let redibujarReloj1 estado =
    mostrarMensajeDerecha 0 ConsoleColor.Yellow $"{estado.Clock1}"

let redibuharReloj2 estado =
    mostrarMensaje 0 0 ConsoleColor.Cyan $"{estado.Clock2}"

let redibujarAlien estado =
    mostrarMensaje estado.AlienX estado.AlienY ConsoleColor.Red "👽"

let redibujarMisiles estado =
    estado.Misiles
    |> List.iter ( fun misil -> 
        mostrarMensaje misil.X misil.Y ConsoleColor.Yellow "=>"
    )

let redibujarPantalla estado =
    Console.Clear()
    
    [|
        redibujarReloj1
        redibuharReloj2
        redibujarAlien
        redibujarMisiles
    |]
    |> Array.iter (fun f -> estado |> f)
    
    estado

let actualizarMisiles estado =
    if estado.Misiles <> [] then 
        estado.Misiles
        |> Seq.map (fun misil -> {misil with X = misil.X+1})
        |> Seq.filter (fun misil -> misil.X < Console.BufferWidth-2)
        |> Seq.toList
        |> fun nuevosMisiles ->
            {estado with Misiles = nuevosMisiles}
    else
        estado
let procesarTeclado key estado =
    match key with  
    | ConsoleKey.UpArrow ->
        {estado with AlienY = max 0 (estado.AlienY-1)}
    | ConsoleKey.DownArrow ->
        {estado with AlienY = min (Console.BufferHeight-1) (estado.AlienY+1)}

    | ConsoleKey.LeftArrow ->
        {estado with AlienX = max 0 (estado.AlienX-1)}
    | ConsoleKey.RightArrow ->
        {estado with AlienX = min (Console.BufferWidth-2) (estado.AlienX+1)}

    | ConsoleKey.Spacebar ->
        let nuevoMisil = {
            X = estado.AlienX+2
            Y = estado.AlienY
        }
        {estado with Misiles = nuevoMisil :: estado.Misiles}
        
    | _ ->
        estado

let actualizarEstado estadoViejo mensaje=
    match mensaje with
    | RelojUnoHizoTick -> {estadoViejo with Clock1=estadoViejo.Clock1+1}
    | RelojDosHizoTick -> {estadoViejo with Clock2=estadoViejo.Clock2+1}
    | Redibujar -> estadoViejo |> redibujarPantalla
    | TeclaPresionada k -> 
        estadoViejo |> procesarTeclado k
    | Animar ->
        estadoViejo |> actualizarMisiles

let buzon = MailboxProcessor.Start (fun bandeja -> 
    let rec loop estado =
        async {
            let! mensaje = bandeja.Receive()
            let nuevoEstado = mensaje |> actualizarEstado estado
            return! loop nuevoEstado
        }

    initialState |> loop

)
let procesarReloj1() =
    async {
        while true do
            do! Async.Sleep 1000
            buzon.Post RelojUnoHizoTick
    }

let procesarReloj2() =
    async {
        while true do
            do! Async.Sleep 250
            buzon.Post RelojDosHizoTick
    }

let refrescarPantalla() =
    async {
        while true do 
            buzon.Post Redibujar
            do! Async.Sleep 25
    }

procesarReloj1() |> Async.StartImmediate
procesarReloj2() |> Async.StartImmediate
refrescarPantalla() |> Async.StartImmediate

let rec leerTeclado() =
    async {
        let salirDelPrograma = 
            Console.KeyAvailable && 
            let k = Console.ReadKey true
            buzon.Post (TeclaPresionada k.Key)
            k.Key = ConsoleKey.Escape
        if not salirDelPrograma then
            do! Async.Sleep 20 
            return! leerTeclado()
            
    }

let rec animarObjetos() =
    async {
        do! Async.Sleep 25
        buzon.Post Animar
        return! animarObjetos()
    }

animarObjetos() |> Async.StartImmediate

Console.CursorVisible <- false

leerTeclado() |> Async.RunSynchronously

Console.CursorVisible <- true
Console.Clear()



//
// La solucion ha este problema se llama el modelo de Actor
// Actor Model.
//
// Whatsapp esta escrito en Erlang.


