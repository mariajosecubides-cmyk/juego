module App.Tipos

type Comando =
| NuevoJuego
| VerHighScore
| Salir