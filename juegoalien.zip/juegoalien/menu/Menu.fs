module App.Menu

open System
open System.Threading
open App.Utils
open App.Tipos

type EstadoDePrograma =
| Ejecutando
| Terminado

type State = {
    EstadoDePrograma: EstadoDePrograma
    RedibujarPantalla: bool
    X: int
    Y: int
    Items: (Comando * string) array
    ItemActivo: int
    HighScore: int
}

let estadoInicial highScore = {
    EstadoDePrograma = Ejecutando
    RedibujarPantalla = true
    X = Console.BufferWidth / 2 - 8
    Y = Console.BufferHeight / 2 - 2
    Items = [|
        NuevoJuego,   "  Nuevo Juego  "
        VerHighScore, "  High Score   "
        Salir,        "  Salir        "
    |]
    ItemActivo = 0
    HighScore = highScore
}

let mostrarTitulo estado =
    let cx = Console.BufferWidth / 2
    mostrarMensajeDerecha 0 ConsoleColor.DarkGray "ESC para salir"
    mostrarMensaje (cx - 12) 2 ConsoleColor.Cyan  "  ☄️  LLUVIA DE METEORITOS  ☄️  "
    mostrarMensaje (cx - 12) 3 ConsoleColor.DarkCyan "--------------------------------"

let mostrarHighScorePanel estado =
    let cx = Console.BufferWidth / 2
    let py = estado.Y + estado.Items.Length + 2
    mostrarMensaje (cx - 8) py ConsoleColor.DarkGray  "┌─────────────────┐"
    mostrarMensaje (cx - 8) (py+1) ConsoleColor.Yellow $"│  🏆 Mejor: {estado.HighScore,-5}  │"
    mostrarMensaje (cx - 8) (py+2) ConsoleColor.DarkGray  "└─────────────────┘"

let mostrarMenu estado =
    // Dibuja cada item del menu
    estado.Items
    |> Array.iteri (fun i (_, etiqueta) ->
        let color =
            if i = estado.ItemActivo then ConsoleColor.Black
            else ConsoleColor.White
        let bg =
            if i = estado.ItemActivo then ConsoleColor.Cyan
            else ConsoleColor.DarkGray
        Console.BackgroundColor <- bg
        mostrarMensaje estado.X (estado.Y + i) color etiqueta
        Console.ResetColor()
    )
    // Flecha indicadora
    mostrarMensaje (estado.X - 3) (estado.Y + estado.ItemActivo) ConsoleColor.Cyan "🚀"

let actualizarTecladoDeMenu tecla estado =
    match tecla with
    | ConsoleKey.Enter    -> { estado with EstadoDePrograma = Terminado }
    | ConsoleKey.UpArrow  -> { estado with ItemActivo = max 0 (estado.ItemActivo - 1) }
    | ConsoleKey.DownArrow -> { estado with ItemActivo = min (estado.Items.Length - 1) (estado.ItemActivo + 1) }
    | _ -> estado
    |> fun s ->
        if s <> estado then { s with RedibujarPantalla = true }
        else estado

let procesarTeclado estado =
    if Console.KeyAvailable then
        let k = Console.ReadKey true
        estado |> actualizarTecladoDeMenu k.Key
    else
        estado

let redibujarPantalla estado =
    if estado.RedibujarPantalla then
        Console.Clear()
        mostrarTitulo estado
        estado |> mostrarMenu
        mostrarHighScorePanel estado
        { estado with RedibujarPantalla = false }
    else
        estado

let rec loopPrincipal estado =
    let nuevoEstado =
        estado
        |> procesarTeclado
        |> redibujarPantalla
    if nuevoEstado.EstadoDePrograma = Ejecutando then
        Thread.Sleep 25
        nuevoEstado |> loopPrincipal
    else
        nuevoEstado

let mostrar highScore =
    Console.CursorVisible <- false
    let colorViejo = Console.ForegroundColor
    let estado = estadoInicial highScore |> loopPrincipal
    Console.ForegroundColor <- colorViejo
    Console.CursorVisible <- true
    Console.Clear()
    estado.Items.[estado.ItemActivo] |> fst