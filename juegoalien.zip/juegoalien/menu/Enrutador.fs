module App.Enrutador

open App.Tipos

type EstadosEnrutador =
| MostrarMenu
| MostrarJuego
| MostrarHighScore
| Terminar

// El enrutador ahora guarda el high score entre partidas
let rec loopPrincipal highScore estado =
    let nuevoEstado, nuevoHighScore =
        match estado with
        | MostrarMenu ->
            match Menu.mostrar highScore with
            | NuevoJuego   -> MostrarJuego, highScore
            | VerHighScore -> MostrarHighScore, highScore
            | Salir        -> Terminar, highScore

        | MostrarJuego ->
            let puntaje = Juego.mostrar ()
            let hsActualizado = max highScore puntaje
            MostrarMenu, hsActualizado

        | MostrarHighScore ->
            // El high score ya se muestra en el menu,
            // esta opcion podria usarse para una pantalla dedicada en el futuro
            MostrarMenu, highScore

        | Terminar ->
            Terminar, highScore

    if nuevoEstado <> Terminar then
        loopPrincipal nuevoHighScore nuevoEstado

let mostrar () =
    loopPrincipal 0 MostrarMenu