module App.Juego

open System
open System.Threading
open App.Utils

// ---------------------------------------------------------------------------
// Mensajes del modelo de Actor
// ---------------------------------------------------------------------------
type Mensaje =
| TickAnimacion
| TickPuntaje
| TickDificultad
| Redibujar
| TeclaPresionada of ConsoleKey
| ObtenerPuntaje of AsyncReplyChannel<int>
| ConsultarTerminado of AsyncReplyChannel<bool>

// ---------------------------------------------------------------------------
// Tipos del estado
// ---------------------------------------------------------------------------
type EstadoNave =
| Viva
| Muerta

type EstadoJuego =
| Jugando
| GameOver
| Terminado

type Meteorito = {
    X: int
    StartTick: int
}

type State = {
    EstadoJuego: EstadoJuego
    EstadoNave: EstadoNave
    ColisionTick: int
    NaveX: int
    Vidas: int
    Puntaje: int
    Tick: int
    Meteoritos: Meteorito list
}

// ---------------------------------------------------------------------------
// Constantes
// ---------------------------------------------------------------------------
let filaDeNave () = Console.BufferHeight - 2
let rng = Random()

// ---------------------------------------------------------------------------
// Estado inicial
// ---------------------------------------------------------------------------
let estadoInicial () = {
    EstadoJuego = Jugando
    EstadoNave = Viva
    ColisionTick = 0
    NaveX = Console.BufferWidth / 2
    Vidas = 3
    Puntaje = 0
    Tick = 0
    Meteoritos = [
        { X = 5;                          StartTick = 0 }
        { X = Console.BufferWidth / 2;    StartTick = 0 }
        { X = Console.BufferWidth - 5;    StartTick = 0 }
    ]
}

// ---------------------------------------------------------------------------
// Fisica de caida: y = 0.5 * g * t^2  (igual que el codigo base)
// ---------------------------------------------------------------------------
let calcularY startTick tickActual =
    let t = float (tickActual - startTick) * 0.025
    let y = 0.5 * 9.77 * t ** 2.0
    int (y * 200.0 / float Console.BufferHeight)

let meteoritoLlego startTick tickActual =
    calcularY startTick tickActual >= Console.BufferHeight - 1

let reiniciarMeteorito tickActual =
    { X = rng.Next(1, Console.BufferWidth - 3); StartTick = tickActual }

// ---------------------------------------------------------------------------
// Logica
// ---------------------------------------------------------------------------
let actualizarMetoritos estado =
    let nuevos =
        estado.Meteoritos
        |> List.map (fun m ->
            if meteoritoLlego m.StartTick estado.Tick then
                reiniciarMeteorito estado.Tick
            else m
        )
    { estado with Meteoritos = nuevos }

let detectarColision estado =
    if estado.EstadoNave = Muerta then estado
    else
        let fila = filaDeNave ()
        let golpeado =
            estado.Meteoritos
            |> List.exists (fun m ->
                let y = calcularY m.StartTick estado.Tick
                y >= fila - 1 && (m.X = estado.NaveX || m.X = estado.NaveX + 1)
            )
        if golpeado then
            let nuevasVidas = estado.Vidas - 1
            let nuevoEstadoJuego =
                if nuevasVidas <= 0 then GameOver else Jugando
            { estado with
                Vidas = nuevasVidas
                EstadoNave = Muerta
                ColisionTick = estado.Tick
                EstadoJuego = nuevoEstadoJuego
                Meteoritos = estado.Meteoritos |> List.map (fun _ -> reiniciarMeteorito estado.Tick)
            }
        else estado

let resetNave estado =
    if estado.EstadoNave = Muerta && estado.EstadoJuego = Jugando then
        if estado.Tick - estado.ColisionTick >= 120 then
            { estado with EstadoNave = Viva }
        else estado
    else estado

// ---------------------------------------------------------------------------
// Dibujo
// ---------------------------------------------------------------------------
let dibujarHUD estado =
    let vidas = String.replicate estado.Vidas "❤️ "
    mostrarMensaje 0 0 ConsoleColor.Red vidas
    mostrarMensajeDerecha 0 ConsoleColor.Cyan $"Puntaje: {estado.Puntaje}"

let dibujarNave estado =
    let sprite = if estado.EstadoNave = Viva then "🚀" else "💥"
    mostrarMensaje estado.NaveX (filaDeNave ()) ConsoleColor.Green sprite

let dibujarMetoritos estado =
    let fila = filaDeNave ()
    estado.Meteoritos
    |> List.iter (fun m ->
        let y = min (fila - 1) (calcularY m.StartTick estado.Tick)
        mostrarMensaje m.X y ConsoleColor.Yellow "☄️"
    )

let dibujarGameOver estado =
    let cy = Console.BufferHeight / 2
    let cx = Console.BufferWidth / 2
    mostrarMensaje (cx - 13) (cy - 2) ConsoleColor.Red    "╔══════════════════════════╗"
    mostrarMensaje (cx - 13) (cy - 1) ConsoleColor.Red    "║        GAME  OVER        ║"
    mostrarMensaje (cx - 13) cy       ConsoleColor.Yellow $"║   Puntaje: {estado.Puntaje,-14}║"
    mostrarMensaje (cx - 13) (cy + 1) ConsoleColor.White  "║  [R] Volver al menu      ║"
    mostrarMensaje (cx - 13) (cy + 2) ConsoleColor.White  "║  [Esc] Salir             ║"
    mostrarMensaje (cx - 13) (cy + 3) ConsoleColor.Red    "╚══════════════════════════╝"

let redibujarPantalla estado =
    Console.Clear()
    match estado.EstadoJuego with
    | GameOver  -> dibujarGameOver estado
    | Jugando   ->
        dibujarHUD estado
        dibujarNave estado
        dibujarMetoritos estado
    | Terminado -> ()
    estado

// ---------------------------------------------------------------------------
// Teclado
// ---------------------------------------------------------------------------
let procesarTeclado key estado =
    match estado.EstadoJuego with
    | GameOver ->
        match key with
        | ConsoleKey.R | ConsoleKey.Escape -> { estado with EstadoJuego = Terminado }
        | _ -> estado
    | Jugando ->
        match key with
        | ConsoleKey.Escape -> { estado with EstadoJuego = Terminado }
        | ConsoleKey.LeftArrow ->
            if estado.EstadoNave = Viva then
                { estado with NaveX = max 0 (estado.NaveX - 1) }
            else estado
        | ConsoleKey.RightArrow ->
            if estado.EstadoNave = Viva then
                { estado with NaveX = min (Console.BufferWidth - 2) (estado.NaveX + 1) }
            else estado
        | _ -> estado
    | Terminado -> estado

// ---------------------------------------------------------------------------
// Buzon de mensajes (modelo de Actor)
// ---------------------------------------------------------------------------
let crearBuzon () =
    MailboxProcessor.Start(fun bandeja ->
        let rec loop estado =
            async {
                let! mensaje = bandeja.Receive()
                let nuevoEstado =
                    match mensaje with
                    | TickAnimacion ->
                        { estado with Tick = estado.Tick + 1 }
                        |> actualizarMetoritos
                        |> detectarColision
                        |> resetNave
                    | TickPuntaje ->
                        if estado.EstadoJuego = Jugando && estado.EstadoNave = Viva then
                            { estado with Puntaje = estado.Puntaje + 1 }
                        else estado
                    | TickDificultad ->
                        if estado.EstadoJuego = Jugando then
                            let extra = reiniciarMeteorito estado.Tick
                            { estado with Meteoritos = extra :: estado.Meteoritos }
                        else estado
                    | Redibujar ->
                        estado |> redibujarPantalla
                    | TeclaPresionada k ->
                        estado |> procesarTeclado k
                    | ObtenerPuntaje canal ->
                        canal.Reply estado.Puntaje
                        estado
                    | ConsultarTerminado canal ->
                        canal.Reply (estado.EstadoJuego = Terminado)
                        estado
                return! loop nuevoEstado
            }
        estadoInicial () |> loop
    )

// ---------------------------------------------------------------------------
// Hilos async (mismo patron del taller de comunicacion entre threads)
// ---------------------------------------------------------------------------
let animarObjetos (buzon: MailboxProcessor<Mensaje>) =
    async {
        while true do
            do! Async.Sleep 25
            buzon.Post TickAnimacion
    }

let subirPuntaje (buzon: MailboxProcessor<Mensaje>) =
    async {
        while true do
            do! Async.Sleep 1000
            buzon.Post TickPuntaje
    }

let subirDificultad (buzon: MailboxProcessor<Mensaje>) =
    async {
        while true do
            do! Async.Sleep 10000
            buzon.Post TickDificultad
    }

let refrescarPantalla (buzon: MailboxProcessor<Mensaje>) =
    async {
        while true do
            buzon.Post Redibujar
            do! Async.Sleep 25
    }

// ---------------------------------------------------------------------------
// Loop de teclado - hilo principal
// ---------------------------------------------------------------------------
let rec leerTeclado (buzon: MailboxProcessor<Mensaje>) =
    async {
        if Console.KeyAvailable then
            let k = Console.ReadKey true
            buzon.Post (TeclaPresionada k.Key)
        
        // Consultamos al buzon si el juego ya termino
        let terminado = buzon.PostAndReply(fun canal -> ConsultarTerminado canal)
        if not terminado then
            do! Async.Sleep 20
            return! leerTeclado buzon
    }

// ---------------------------------------------------------------------------
// Punto de entrada del modulo - retorna el puntaje final
// ---------------------------------------------------------------------------
let mostrar () =
    Console.Clear()
    Console.CursorVisible <- false
    let colorViejo = Console.ForegroundColor

    let buzon = crearBuzon ()

    animarObjetos buzon     |> Async.StartImmediate
    subirPuntaje buzon      |> Async.StartImmediate
    subirDificultad buzon   |> Async.StartImmediate
    refrescarPantalla buzon |> Async.StartImmediate

    leerTeclado buzon |> Async.RunSynchronously

    // Pedimos el puntaje final al buzon antes de salir
    let puntajeFinal = buzon.PostAndReply(fun canal -> ObtenerPuntaje canal)

    Console.CursorVisible <- true
    Console.ForegroundColor <- colorViejo
    Console.Clear()
    puntajeFinal